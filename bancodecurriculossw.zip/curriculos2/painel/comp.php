<?php
session_start();
include 'conecta.php';
  
$sql = "SELECT * FROM curriculo";
$resultado = mysqli_query($conexao,$sql);
while($chave = mysqli_fetch_assoc($resultado)){
    $dado = $chave['id_curr'];
}
$tipo_cad = $_SESSION['tipo_cad'];

switch($tipo_cad){
    case 'com':
        $comp = $_POST['comp'];
        $sql = "INSERT INTO competencias (competencia, id_curr) VALUES ('$comp','$dado')";
        break;

    case 'hab':
        $habi = $_POST['habi'];
        $sql = "INSERT INTO habilidades (habilidade, id_curr) VALUES ('$habi','$dado')";
       
        break;

    case 'edu':
        $comp = $_POST['comp'];
        $sql = "INSERT INTO educacao (competencia, id_curr) VALUES ('$comp','$dado')";
       
        break;

    case 'exp':
        $comp = $_POST['comp'];
        $sql = "INSERT INTO experiencia (competencia, id_curr) VALUES ('$comp','$dado')";
       
        break;
    }

    mysqli_query($conexao, $sql);
    mysqli_close($conexao);
    header("Location: index.php");
?>  