<?php
include 'conecta.php';
 
$nome = $_POST['nome'];
$email = $conexao->real_escape_string(strtolower($_POST['email']));
$cpf = $_POST['cpf'];
$senha = md5($conexao->real_escape_string($_POST['senha']));
$senha2 = md5($conexao->real_escape_string($_POST['senha2']));

if($senha==$senha2){ 
    $sql = "INSERT INTO usuarios (nome, email, cpf, tipo, senha) VALUES ('$nome','$email','$cpf',2,'$senha')";
    mysqli_query($conexao,$sql);
    session_start();
}else{
    echo "<script> alert('Digite a mesma senha')</script>";
}
mysqli_close($conexao);
header("Location: login.php");
?> 