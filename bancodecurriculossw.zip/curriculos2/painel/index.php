<?php
    include 'session.php';
    include 'conecta.php';
 
    switch($_SESSION['tipo_user']){
        case 1:        
            $tipo = 'Administrador';
            break;
        case 2:
            $tipo = 'Aluno';
            break; 
        case 3:
            $tipo = 'Empresa';
            break;
        }
    $cpf = $_SESSION['cpf_user'];
     
    include 'botoes.php';    
?> 



<!DOCTYPE html>
<html lang="pt-br">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Painel Administrativo</title>

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/estilo.css">

</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.php">
                <div class="sidebar-brand-icon rotate-n-15">
                    <i class="fas fa-laugh-wink"></i>
                </div>
                <div class="sidebar-brand-text mx-3">Banco de Currículos</div>
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <li class="nav-item active">
                <a class="nav-link" href="index.php">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>Painel</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider">

            <!-- Heading -->
            <div class="sidebar-heading">
                Interface
            </div>

            <!-- Nav Item - Pages Collapse Menu -->
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-cog"></i>
                    <span>Empresas</span>
                </a>
                <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <h6 class="collapse-header">Vagas:</h6>
                        <a class="collapse-item" href="#">Abertas</a>
                        <a class="collapse-item" href="#">Fechadas</a>
                    </div>
                </div>
            </li>

            <!-- Nav Item - Utilities Collapse Menu -->
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseUtilities"
                    aria-expanded="true" aria-controls="collapseUtilities">
                    <i class="fas fa-fw fa-wrench"></i>
                    <span>Meu Currículo</span>
                </a>
                <div id="collapseUtilities" class="collapse" aria-labelledby="headingUtilities"
                    data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <h6 class="collapse-header">Acesso Rápido:</h6>
                        <?php
                        if($cad == false){
                            ?>
                        <a class="collapse-item" href="cadastrar_curriculo.php">Cadastrar</a>
                        <?php
                        }else{
                            ?>
                        <a class="collapse-item" href="#hab">Habilidades</a>
                        <a class="collapse-item" href="#com">Competências</a>
                        <a class="collapse-item" href="#edu">Educação</a>
                        <a class="collapse-item" href="#exp">Experiência</a>
                        <?php
                        }
                        ?>
                        <a class="collapse-item" href="dados_pessoais.php">Dados Pessoais</a>
                    </div>
                </div>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider">

            <!-- Heading -->
            <div class="sidebar-heading">
                Candidaturas
            </div>

            <!-- Nav Item - Pages Collapse Menu -->
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePages"
                    aria-expanded="true" aria-controls="collapsePages">
                    <i class="fas fa-fw fa-folder"></i>
                    <span>Processos</span>
                </a>
                <div id="collapsePages" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">                        
                        <a class="collapse-item" href="#">Em Andamento</a>                        
                        <div class="collapse-divider"></div>                        
                        <a class="collapse-item" href="#">Encerrados</a>                        
                    </div>
                </div>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider d-none d-md-block">

            

        </ul>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                    <!-- Sidebar Toggle (Topbar) -->
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>
                    
                    <!-- Topbar Navbar -->
                    <ul class="navbar-nav ml-auto">

                        <div class="topbar-divider d-none d-sm-block"></div>

                        <!-- Nav Item - User Information -->
                        <li class="nav-item dropdown no-arrow">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span class="mr-2 d-none d-lg-inline text-gray-600 small">Bem vindo <b><?php echo $_SESSION['nome_user']; ?></b></span>
                                <img class='img-profile rounded-circle' src='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAAgVBMVEX///8AAABmZmZ4eHh8fHxjY2Pv7+/z8/N6enpoaGjFxcX6+vpgYGBbW1vIyMhtbW2IiIi5ubmVlZXg4OCtra2hoaHn5+fZ2dmBgYGenp5DQ0MUFBQ5OTkbGxs+Pj66urovLy9UVFQnJyfS0tIXFxePj48yMjJKSkoMDAwpKSmpqalHQmn7AAAHtUlEQVR4nO2daUPiMBCGyyKtggKFUg5FQOSQ//8D1x5ArslRWpIJPh/Xujvv5piZZJIEwR+oiaaJbRMaJO3uNsvWyLYZDTFNBl+tnJ5tU+on6o/eWhc8a8LeOG4vWiTH0LZN9dHrzzdfLZahbbNqIo2HvLgcD5ownM4H72J1v8xsm3cj4+5scwTVYW/CbfIKdEyCgW0rq/OpFJcztm1ndYZaAt9sm3kDW7W8zmSFeRQGKn1D1OoyXqX6RpFt+27nSaJvgXiCuTKQNKBt2+oBdBfHrW3T6iGEBO7RzzAlE0Bgx5d8NwIEIo7SGP6JBbZt21UbgKt4tm1XbbTFArHnglcAgb6sVwTB8yOOwY8D6kSJhu+iX0kaBL64QYHAo2fbElwX3fgSpJVwk8yrbYtqhuuivgnkWvDFtkU1w43Bf7Ytqhmui/rjAQs4gb61INdFvR+DHdsW1czjjUHvu6hvAh8vVPNtkvkL1bDzeG7Ctxb03k08XqjmvR/0vov6JvDx3IRvk4z3XfTx3IT3Y/AvVEMGJ9D7SMY3gX8ZPXYez0345ugfz0341oKPNwZ9m0W9dxPeb77gFzjuS3+M3k30X+UF5tjdxCo7Wi0rr8PtJnpJfsyzK/kEdagWTYoTyLI+inkMhrvyhPVSUr+LOKNPrx5AMpFybgLNGJx2rkZLDglwArFEMn3i3o3WO9xHsYZq4YayOgY/xNpFU9rqBfgh1lCtt6bNBg90Yu2iwYg2ewN9hzdUY+yGohm8odqKtvsD+AxxRr+jDQfOjaMdg7/sacvFJ/8Rh2pBj7b8R/gRVjeR06dNFx5bRRuq5TC+YiL4BPMY/IW+Kq214r/AGqqVjBnr+byJE4jG0RckjPlcGyLvokHQYexn3SHeUK2Eu6xiSf8c+RgMuJCtxUymiEO1M4K7DojIG/0Y5AKagtl5EYMTiK6L8jNpyWsSx8mQu/QIU6h2RvOiP6xdNAimJgKxuYkcyfViHAjHIB+xedeCJk2IcQxq3UV5BuMs+starawE5RgEbzbyposGJ98FjtTKUHfR7Ye2QIyTTBQftPVh7KLT4be+PnyOfjwxirWxjcHtTn7bO+4WTOO2SecsQDMGw+6TWd8swTGLhquhvmOgAfeCnSGaTtTJw64X9ADn7/b9zNkjEjrtVNSVdEU/+nb2ivRoe+rsRSaDArkdthwnp5mof3oxmTGvlUECiXDZkB3C7miwNBCXQW7C8B3VrXvuwxdDcRn0XigrUVZ/eX+gu8ClsFUljMS9FSUQ8ncjAJ7Yv4Uei3BxmwUqNaGgzplqRacUiuZ6DXh/R0p0qpfG1RQKMiNColOvu+1gFVIEJfaEREFRRsn9Z9kqriJHcOTgut12gP655P6u0mDVRd2K1/IaUe3Qb8R7aH02rIejpxuFCuCTeCLRENwrnmbZivzMVwOkpmsTJFxHnRE/HDIjbtoW/680jdE2Z4ttcFYi9bbdngi/x0k5Gu4fsOovzxcJ75z+IzpLmjG/sBwkcX+7Sp4u2zhcLNQ8wOMYIgoPwOyqkRI1nrezEJEv1FaVAAnvtaNqCBTPsI2iH5WCCe9ZokbosLbQhNo7uWSQwkgspkedFxjhSKc55mqzck7UbzES18lYa7vGygrjRk8gU3NYMSGZ2lCoaRv3LE8ViVaOw+oayudKBqUYZ6xkVNq71XzCa9yKJ8G/3zzaey6CfRbhWjeMnQe2wFcTeQSDyKQVv2Un9BvEZAVDkBTwRdAifhb/5ndPmc4AjwqKEbTiRvEr68Fpmt5f1pUIfoNdT6J0onpJUusr34ZzBb+hBEdqH4l1dRkGmVMBO6NCj7kfrI07BlOBbEdlE94Sd55+uzXyAtKlN3e2f41m0jPXjgoMQoeezqy2JXPxi4BAC1k8CHAeREkxowICnXrdVX+FhmGdbKGE98u2KBKzhVJNrOS4EFX3nGQ4deUTeyVJLTjVhBW3fqW49c65yaElXZwqohEejrwRtypmqzpDGa6E2wVQVnADR9uaKODM8Hg8vptXPGfMbYuieOPs28wm3XEaZkRROO5OduxtAipcKjBhDkf+zGKxdf2RwSa/U96eOEi+7MTSpaKtdjGKpeVCMZe8adBVZ6upXmXf0p28Nzjv3R9iTaMmOgrdimeyEwZtgwBEZ8XKqU4aHBZzo4lPJzxoytZqmC5lakTpbnVSYzS2N9zqpMZoTDVOrHBXR70cgOykIQewtk3gVkxqjjpbdir3rYAy1fpAPgzVi+PPtk28EXVhCXJfoS5BdersQRWUYSlYmI8F5UTj0n5TFdQLj04tdVdAXc9g28JbUcZsyPMKjUM1zhQmVCRUlhVZrXqqAaW/Z+uH0aEsQUU/DPnlcQbs3lBdgoo9c1LWkP44tRRcAWV+j+MeGglKX2GnQL0+1Fd4YveGyoVE7qwJNpQhG/IVGvUSDXZXocqcFugF8reOk7xjTyoyZHeZjbAPwQyJr5j5oE/iK9rYveAZoKRmg33p6YLYV3y6fZ2eEaK8Yu3aTWw3we+qvZ/8mGDOcAK9cBAEbEAzw57rctABzcAXB0FA3qT45o2DICAWSvduFTjXxeVkk18OgqA8q/+NfT0UpIy6R95NoBfye13a/urLF0pf8KfwMtKRjw7CF/4D5I9X3zxB2UoAAAAASUVORK5CYII='>
                            </a>
                            <!-- Dropdown - User Information -->
                            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in"
                                aria-labelledby="userDropdown">
                                <a class="dropdown-item" href="dados_pessoais.php">
                                    <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Perfil
                                </a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="logout.php" data-toggle="modal" data-target="#logoutModal">
                                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Sair
                                </a>
                            </div>
                        </li>

                    </ul>
                    <ul class="navbar-nav ml-auto">

                        <div class="topbar-divider d-none d-sm-block"></div>

                        <!-- Nav Item - User Information -->
                        <li class="nav-item">
                            <?php echo "<p>Logado como $tipo</p>"; ?>
                        </li>

                    </ul>

                </nav>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Vagas Recentes</h1>                        
                    </div>

                    <!-- Content Row -->
                    <div class="row">

                        <!-- Earnings (Monthly) Card Example -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-primary shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                                Empresa 1</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">INSCREVER-SE</div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-calendar fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Earnings (Monthly) Card Example -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-success shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                            Empresa 2</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">INSCREVER-SE</div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-dollar-sign fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Earnings (Monthly) Card Example -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-primary shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                            Empresa 3</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">INSCREVER-SE</div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-calendar fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div> 
                        <!-- Earnings (Monthly) Card Example -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-primary shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                            Empresa 4</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">INSCREVER-SE</div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-calendar fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>    
                     </div>
                     <?php
                     include "botao_cad.php";
                     ?>
                        <div class="card shadow mb-4">
                            <div class="card-header py-3">
                                <h6 class="m-0 font-weight-bold text-primary">Dados Pessoais</h6>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                        <thead>
                                            <tr>
                                                <th>ID</th>
                                                <th>Nome</th>
                                                <th>Email</th>
                                                <th>Telefone</th>
                                                <th>Curso</th>
                                                <?php
                                                if($cad){
                                                    ?>
                                                    <th>CPF</th>
                                                    <?php
                                                }
                                                ?>                                
                                            </tr>
                                        </thead>
                                        <tbody>

                                        <?php
                                        $email = $_SESSION['email_user'];
                                        $sql = "SELECT * FROM curriculo";
                                        
                                        $resultado = mysqli_query($conexao,$sql);

                                        if(mysqli_num_rows($resultado)>0){
                                            while($linha = mysqli_fetch_assoc($resultado)){
                                        ?>
                                            <tr>
                                                <td><?php echo $linha['id_curr'] ?></td>
                                                <td><?php echo $linha['nome'] ?></td>
                                                <td><?php echo $linha['email'] ?></td>
                                                <td><?php echo $linha['telefone'] ?></td>
                                                <td><?php echo $linha['curso'] ?></td>
                                                <?php
                                                if($cad){
                                                    ?>
                                                    <th><?php echo "$cpf"?></th>
                                                    <?php
                                                }
                                                ?>  
                                            </tr>

                                        <?php
                                            }
                                        }else {
                                            echo "0 resultados encontrados";
                                        }
                                        ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <?php
                            if($cad == false){
                                ?>
                                <p class='aviso'>Você ainda não cadastrou seu currículo!</p>
                                <?php
                            }
                            ?>
                        </div>

                        <?php
                        if($cad){                               
                            $sql = 'SELECT * FROM habilidades';
                            
                            $resultado = mysqli_query($conexao,$sql);

                            if(mysqli_num_rows($resultado)==0){
                                ?>
                            <a href="cadastrar_habilidades.php" class="btn btn-secondary btn-icon-split" id="hab">
                                <span class="icon text-white-50">
                                    <i class="fas fa-arrow-right"></i>
                                    
                                </span>
                                <span class="text">Cadastrar Habilidades</span>
                            </a>                                
                            <p class="aviso">Você ainda não cadastrou nenhuma habilidade!</p>

                            <?php
                            }else{
                                ?>
                                <a href="cadastrar_habilidades.php" class="btn btn-secondary btn-icon-split" id="hab">
                                    <span class="icon text-white-50">
                                        <i class="fas fa-arrow-right"></i>
                                    </span>
                                    <span class="text">Cadastrar outra habilidade</span>
                                </a>
                                <?php
                            }
                            ?>
                        <div class="my-2"></div>
                        <div class='card shadow mb-4'>
                            <div class='card-header py-3'>
                                <h6 class='m-0 font-weight-bold text-primary'>Habilidades</h6>
                            </div>
                            <div class='card-body'>
                                <div class='table-responsive'>
                                    <table class='table table-bordered' id='dataTable' width='100%' cellspacing='0'>
                                        <thead>
                                            <tr>
                                                <th>ID_Hab</th>
                                                <th>Habilidade</th>
                                                <th>ID_Curr</th>                              
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php                                
                                        $sql = 'SELECT * FROM habilidades';
                                        
                                        $resultado = mysqli_query($conexao,$sql);

                                        if(mysqli_num_rows($resultado)>0){
                                            while($linha = mysqli_fetch_assoc($resultado)){
                                        ?>
                                            <tr>
                                                <td><?php echo $linha['id_hab']?></td>
                                                <td><?php echo $linha['habilidade']?></td>
                                                <td><?php echo $linha['id_curr']?></td>
                                             </tr>
                                            <?php
                                            }
                                        }else {
                                            echo '0 resultados encontrados';
                                        }
                                        ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div> 
                        <?php                             
                            $sql = 'SELECT * FROM competencias';
                            
                            $resultado = mysqli_query($conexao,$sql);

                            if(mysqli_num_rows($resultado)==0){
                                ?>
                            <a href="cadastrar_competencias.php" class="btn btn-secondary btn-icon-split" id="com">
                                <span class="icon text-white-50">
                                    <i class="fas fa-arrow-right"></i>
                                </span>
                                <span class="text">Cadastrar Competências</span>
                            </a>                                
                            <p class="aviso">Você ainda não cadastrou nenhuma competência!</p>

                            <?php
                            }else{
                                ?>
                                <a href="cadastrar_competencias.php" class="btn btn-secondary btn-icon-split" id="com">
                                    <span class="icon text-white-50">
                                        <i class="fas fa-arrow-right"></i>
                                    </span>
                                    <span class="text">Cadastrar outra competência</span>
                                </a>
                                <?php
                            }
                            ?>
                        <div class="my-2"></div>
                        <div class='card shadow mb-4'>
                            <div class='card-header py-3'>
                                <h6 class='m-0 font-weight-bold text-primary'>Competências</h6>
                            </div>
                            <div class='card-body'>
                                <div class='table-responsive'>
                                    <table class='table table-bordered' id='dataTable' width='100%' cellspacing='0'>
                                        <thead>
                                            <tr>
                                                <th>ID_Comp</th>
                                                <th>Competência</th>
                                                <th>ID_Curr</th>                                 
                                            </tr>
                                        </thead>
                                        <tbody>

                                        <?php
                                        
                                        $sql = 'SELECT * FROM competencias';
                                        
                                        $resultado = mysqli_query($conexao,$sql);

                                        if(mysqli_num_rows($resultado)>0){
                                            while($linha = mysqli_fetch_assoc($resultado)){
                                        ?>
                                            <tr>
                                                <td><?php echo $linha['id_comp'] ?></td>
                                                <td><?php echo $linha['competencia'] ?></td>
                                                <td><?php echo $linha['id_curr'] ?></td>
                                            </tr>

                                        <?php
                                            }
                                        }else {
                                            echo '0 resultados encontrados';
                                        }
                                        ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>     
                        <?php                         
                            $sql = 'SELECT * FROM educacao';
                            
                            $resultado = mysqli_query($conexao,$sql);

                            if(mysqli_num_rows($resultado)==0){
                                ?>
                            <a href="cadastrar_educacao.php" class="btn btn-secondary btn-icon-split" id="edu">
                                <span class="icon text-white-50">
                                    <i class="fas fa-arrow-right"></i>
                                </span>
                                <span class="text">Cadastrar Educação</span>
                            </a>                                
                            <p class="aviso">Você ainda não cadastrou nenhuma formação!</p>

                            <?php
                            }else{
                                ?>
                                <a href="cadastrar_educacao.php" class="btn btn-secondary btn-icon-split" id="edu">
                                    <span class="icon text-white-50">
                                        <i class="fas fa-arrow-right"></i>
                                    </span>
                                    <span class="text">Cadastrar outra formação</span>
                                </a>
                                <?php
                            }
                            ?>
                        <div class="my-2"></div>
                        <div class='card shadow mb-4'>
                            <div class='card-header py-3'>
                                <h6 class='m-0 font-weight-bold text-primary'>Educação</h6>
                            </div>
                            <div class='card-body'>
                                <div class='table-responsive'>
                                    <table class='table table-bordered' id='dataTable' width='100%' cellspacing='0'>
                                        <thead>
                                            <tr>
                                                <th>ID_Educ</th>
                                                <th>Instituição</th>
                                                <th>Curso</th>
                                                <th>Início</th>
                                                <th>Fim</th>
                                                <th>ID_Curr</th>                            
                                            </tr>
                                        </thead>
                                        <tbody>

                                        <?php
                                        
                                        $sql = 'SELECT * FROM educacao';
                                        
                                        $resultado = mysqli_query($conexao,$sql);

                                        if(mysqli_num_rows($resultado)>0){
                                            function data($data){
                                                return date("d/m/Y", strtotime($data));
                                            }
                                            while($linha = mysqli_fetch_assoc($resultado)){
                                        ?>
                                            <tr>
                                                <td><?php echo $linha['id_educ'] ?></td>
                                                <td><?php echo $linha['instituicao'] ?></td>
                                                <td><?php echo $linha['curso'] ?></td>
                                                <td><?php
                                                echo data($linha['inicio']);
                                                ?></td>
                                                <td><?php  
                                                if($linha['fim'] !='0000-00-00'){
                                                    echo data($linha['fim']);
                                                    }else{
                                                        echo "Em Andamento";
                                                    } 
                                                    ?></td>
                                                <td><?php echo $linha['id_curr'] ?></td>
                                              </tr>
                                        <?php
                                            }
                                        }else {
                                            echo '0 resultados encontrados';
                                        }
                                        ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>              
                        <?php                
                            $sql = 'SELECT * FROM experiencia';
                            
                            $resultado = mysqli_query($conexao,$sql);

                            if(mysqli_num_rows($resultado)==0){
                                ?>
                            <a href="cadastrar_experiencia.php" class="btn btn-secondary btn-icon-split" id="exp">
                                <span class="icon text-white-50">
                                    <i class="fas fa-arrow-right"></i>
                                </span>
                                <span class="text">Cadastrar Experiência</span>
                            </a>                                
                            <p class="aviso">Você ainda não cadastrou nenhuma experiência!</p>

                            <?php
                            }else{
                                ?>
                                <a href="cadastrar_experiencia.php" class="btn btn-secondary btn-icon-split" id="exp">
                                    <span class="icon text-white-50">
                                        <i class="fas fa-arrow-right"></i>
                                    </span>
                                    <span class="text">Cadastrar outra experiência</span>
                                </a>
                                <?php
                            }
                            ?>
                        <div class="my-2"></div>
                        <div class='card shadow mb-4'>
                            <div class='card-header py-3'>
                                <h6 class='m-0 font-weight-bold text-primary'>Experiência Profissional</h6>
                            </div>
                            <div class='card-body'>
                                <div class='table-responsive'>
                                    <table class='table table-bordered' id='dataTable' width='100%' cellspacing='0'>
                                        <thead>
                                            <tr>
                                                <th>ID_Exp</th>
                                                <th>Ocupação</th>
                                                <th>Empresa</th>
                                                <th>Início</th>
                                                <th>Fim</th>      
                                                <th>ID_Curr</th>                               
                                            </tr>
                                        </thead>
                                        <tbody>

                                        <?php
                                        
                                        $sql = 'SELECT * FROM experiencia';
                                        
                                        $resultado = mysqli_query($conexao,$sql);

                                        if(mysqli_num_rows($resultado)>0){                                             
                                            function data2($data){
                                                return date("d/m/Y", strtotime($data));
                                            }
                                            while($linha = mysqli_fetch_assoc($resultado)){
                                        ?>
                                            <tr>
                                                <td><?php echo $linha['id_exp'] ?></td>
                                                <td><?php echo $linha['ocupacao'] ?></td>
                                                <td><?php echo $linha['empresa'] ?></td>
                                                <td><?php
                                                echo data2($linha['inicio']);
                                                ?></td>
                                                <td><?php  
                                                if($linha['fim'] !='0000-00-00'){
                                                    echo data2($linha['fim']);
                                                    }else{
                                                        echo "Em Andamento";
                                                    } 
                                                    ?></td>
                                                <td><?php echo $linha['id_curr'] ?></td>
                                            </tr>

                                        <?php
                                            }
                                        }else {
                                            echo '0 resultados encontrados';
                                        }
                                        mysqli_close($conexao);
                                        ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <?php
                        }
                        ?>
                        
                    </div>

                    <!-- Content Row -->


                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->
        </div>
            <!-- Footer -->
            <footer class='sticky-footer bg-white'>
                <div class='container my-auto'>
                    <div class='copyright text-center my-auto'>
                        <span>Copyright &copy; Banco de Currículos ETEC MCM 2022</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class='scroll-to-top rounded' href='#page-top'>
        <i class='fas fa-angle-up'></i>
    </a>

    <!-- Logout Modal-->
    <div class='modal fade' id='logoutModal' tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Deseja sair?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Selecione "Sair" para encerrar sua sessão ativa.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancelar</button>
                    <a class="btn btn-primary" href="logout.php">Sair</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/chart.js/Chart.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/chart-area-demo.js"></script>
    <script src="js/demo/chart-pie-demo.js"></script>
    <style>
        .red{
            background-color: red;
            color: white;
            font-weight: bold;
        }
        .invi{
            display: none;
        }
    </style>

</body>

</html>