<?php
session_start();
$_SESSION['senhaincorreta'] = false;
$senhainc = $_SESSION['senhaincorreta'];
if($senhainc){
    echo "<script>
            alert('Email e/ou senha incorreto(s)');
        </script>";
}
if($_SESSION['curricria']){
    echo "<script>
            alert('Conta criada com sucesso');
        </script>";
        $_SESSION['curricria'] = false;
}
?>  