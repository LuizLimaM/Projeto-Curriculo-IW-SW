 <?php               
                     if($cad == false){
                        echo "             <br><a href=\"cadastrar_curriculo.php\" class=\"btn btn-secondary btn-icon-split\">
                                            <span class=\"icon text-white-50\">
                                                <i class=\"fas fa-arrow-right\"></i>
                                            </span>
                                            <span class=\"text\">Cadastrar Currículo</span>
                                        </a>
                                        <div class=\"my-2\"></div>";
                     } 
?>  