<?php
    $sql = "SELECT * FROM curriculo WHERE email= '$email_user'";
    $resultado = mysqli_query($conexao,$sql);
    if(mysqli_num_rows($resultado)>0){
        while($lista= mysqli_fetch_assoc($resultado)){
            $nome = $lista['nome'];
            $telefone = $lista['telefone'];
            $curso = $lista['curso'];
        }
    }
    $sql = "SELECT * FROM usuarios WHERE email= '$email_user'";
    $resultado = mysqli_query($conexao,$sql);
    if(mysqli_num_rows($resultado)>0){
        while($lista= mysqli_fetch_assoc($resultado)){
            $cpf = $lista['cpf'];
        }
    }

    $i = 0;
    $sql = "SELECT * FROM competencias";
    $resultado = mysqli_query($conexao,$sql);
    if(mysqli_num_rows($resultado)>0){
        while($lista= mysqli_fetch_assoc($resultado)){
            $competencia[$i] = $lista['competencia'];
            $i++;
        }
    }else{
        $competencia[0] = 'false';
    }

    $i = 0;
    $sql = "SELECT * FROM habilidades";
    $resultado = mysqli_query($conexao,$sql);
    if(mysqli_num_rows($resultado)>0){
        while($lista= mysqli_fetch_assoc($resultado)){
            $habilidade[$i] = $lista['habilidade'];
            $i++;
        }
    }else{
        $habilidade[0] = 'false';
    }
?>